function openAdd() {
 document.getElementById("empForm").action="/employees/save";
 document.getElementById("title").innerText="Add Employee";
 document.getElementById("modal").style.display="block";
}

function openEdit(id,name,email,phone,gender,salary,role,exp,bonus){
 document.getElementById("empForm").action="/employees/update";
 document.getElementById("title").innerText="Update Employee";

 id && (document.getElementById("id").value=id);
 name && (document.getElementById("name").value=name);
 email && (document.getElementById("email").value=email);
 phone && (document.getElementById("phone").value=phone);
 gender && (document.getElementById("gender").value=gender);
 salary && (document.getElementById("salary").value=salary);
 role && (document.getElementById("role").value=role);
 exp && (document.getElementById("experience").value=exp);
 bonus && (document.getElementById("bonus").value=bonus);

 document.getElementById("modal").style.display="block";
}

function closeModal(){
 document.getElementById("modal").style.display="none";
}
