package com.ems.repository;

import com.ems.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class UserRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public User findByUsernameAndPassword(String username, String password) {

        String sql = "SELECT * FROM users WHERE username=? AND password=?";

        return jdbcTemplate.query(
                sql,
                (rs, rowNum) -> {
                    User user = new User();
                    user.setId(rs.getInt("id"));
                    user.setUsername(rs.getString("username"));
                    user.setPassword(rs.getString("password"));
                    user.setRole(rs.getString("role"));
                    user.setEmployeeId(rs.getLong("employee_id"));
                    return user;
                },
                username,
                password
        ).stream().findFirst().orElse(null);
    }
}

