package com.ems.controller;

import com.ems.admin.AdminService;
import com.ems.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class EmployeeController {

    @Autowired
    private AdminService adminService;

    // ---------------- ADMIN DASHBOARD ----------------
    @GetMapping("/employees")
    public String adminPage(Model model) {
        model.addAttribute("employees", adminService.getAllEmployees());
        return "index";
    }

    // ---------------- ADD EMPLOYEE PAGE ----------------
    @GetMapping("/employees/add")
    public String addEmployee(Model model) {
        model.addAttribute("employee", new Employee());
        return "add";
    }

    // ---------------- SAVE EMPLOYEE ----------------
    @PostMapping("/employees/save")
    public String saveEmployee(@ModelAttribute Employee employee) {
        adminService.addEmployee(employee);
        return "redirect:/employees";
    }

    // ---------------- EDIT EMPLOYEE PAGE ----------------
    @GetMapping("/employees/edit/{id}")
    public String editEmployee(@PathVariable Long id, Model model) {
        Employee emp = adminService.getEmployeeById(id);
        model.addAttribute("employee", emp);
        return "edit";
    }

    // ---------------- UPDATE EMPLOYEE ----------------
    @PostMapping("/employees/update")
    public String updateEmployee(@ModelAttribute Employee employee) {
        adminService.updateEmployee(employee);
        return "redirect:/employees";
    }

    // ---------------- DELETE EMPLOYEE ----------------
    @GetMapping("/employees/delete/{id}")
    public String deleteEmployee(@PathVariable Long id) {
        adminService.deleteEmployee(id);
        return "redirect:/employees";
    }

    // ---------------- DELETE ALL ----------------
    @GetMapping("/employees/deleteAll")
    public String deleteAll() {
        adminService.deleteAllEmployees();
        return "redirect:/employees";
    }
}

