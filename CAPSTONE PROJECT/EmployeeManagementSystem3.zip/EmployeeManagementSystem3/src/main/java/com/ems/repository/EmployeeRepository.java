package com.ems.repository;

import com.ems.model.Employee;   // ✅ THIS WAS MISSING

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class EmployeeRepository {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    // ---------- FIND ALL ----------
    public List<Employee> findAll() {
        String sql = "SELECT * FROM employee";
        return jdbcTemplate.query(sql, (rs, rowNum) -> mapEmployee(rs));
    }

    // ---------- FIND BY ID ----------
    public Employee findById(Long id) {
        String sql = "SELECT * FROM employee WHERE id=?";
        return jdbcTemplate.query(
                sql,
                (rs, rowNum) -> mapEmployee(rs),
                id
        ).stream().findFirst().orElse(null);
    }

    // ---------- SAVE ----------
    public void save(Employee e) {
        String sql = "INSERT INTO employee (name,email,phone,gender,salary,role,experience,bonus) VALUES (?,?,?,?,?,?,?,?)";
        jdbcTemplate.update(sql,
                e.getName(),
                e.getEmail(),
                e.getPhone(),
                e.getGender(),
                e.getSalary(),
                e.getRole(),
                e.getExperience(),
                e.getBonus()
        );
    }

    // ---------- UPDATE ----------
    public void update(Employee e) {
        String sql = "UPDATE employee SET name=?, email=?, phone=?, gender=?, salary=?, role=?, experience=?, bonus=? WHERE id=?";
        jdbcTemplate.update(sql,
                e.getName(),
                e.getEmail(),
                e.getPhone(),
                e.getGender(),
                e.getSalary(),
                e.getRole(),
                e.getExperience(),
                e.getBonus(),
                e.getId()
        );
    }

    // ---------- DELETE BY ID ----------
    public void deleteById(Long id) {
        String sql = "DELETE FROM employee WHERE id=?";
        jdbcTemplate.update(sql, id);
    }

    // ---------- DELETE ALL ----------
    public void deleteAll() {
        jdbcTemplate.update("DELETE FROM employee");
    }

    // ---------- ROW MAPPER ----------
    private Employee mapEmployee(ResultSet rs) throws SQLException {
        Employee e = new Employee();
        e.setId(rs.getLong("id"));
        e.setName(rs.getString("name"));
        e.setEmail(rs.getString("email"));
        e.setPhone(rs.getLong("phone"));
        e.setGender(rs.getString("gender"));
        e.setSalary(rs.getDouble("salary"));
        e.setRole(rs.getString("role"));
        e.setExperience(rs.getInt("experience"));
        e.setBonus(rs.getDouble("bonus"));
        return e;
    }
}
