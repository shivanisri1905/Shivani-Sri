package com.ems.controller;

import com.ems.model.Employee;
import com.ems.model.User;
import com.ems.repository.EmployeeRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class UserController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/user-dashboard")
    public String userDashboard(HttpSession session, Model model) {

        User user = (User) session.getAttribute("loggedUser");

        if (user == null || !"USER".equalsIgnoreCase(user.getRole())) {
            return "redirect:/login";
        }

        Employee employee =
                employeeRepository.findById(user.getEmployeeId());

        model.addAttribute("employee", employee);
        return "user-dashboard";
    }
}
