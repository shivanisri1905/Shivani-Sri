package com.ems.model;

public class Employee {

    private Long id;
    private String name;
    private String email;
    private Long phone;
    private String gender;
    private double salary;
    private String role;
    private int experience;
    private double bonus;

    // ✅ Default constructor (REQUIRED)
    public Employee() {
    }

    // ✅ Parameterized constructor (FOR JUNIT)
    public Employee(Long id, String name, String email,
                    Long phone, String gender, double salary,
                    String role, int experience, double bonus) {

        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.gender = gender;
        this.salary = salary;
        this.role = role;
        this.experience = experience;
        this.bonus = bonus;
    }

    // -------- GETTERS & SETTERS --------

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public Long getPhone() { return phone; }
    public void setPhone(Long phone) { this.phone = phone; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public double getSalary() { return salary; }
    public void setSalary(double salary) { this.salary = salary; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public int getExperience() { return experience; }
    public void setExperience(int experience) { this.experience = experience; }

    public double getBonus() { return bonus; }
    public void setBonus(double bonus) { this.bonus = bonus; }
}

