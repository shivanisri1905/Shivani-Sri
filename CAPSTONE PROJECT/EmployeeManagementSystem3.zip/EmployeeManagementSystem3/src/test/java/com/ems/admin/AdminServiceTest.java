package com.ems.admin;

import com.ems.model.Employee;
import com.ems.repository.EmployeeRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class AdminServiceTest {

    @Mock
    private EmployeeRepository employeeRepository;

    @InjectMocks
    private AdminService adminService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    // ---------- TEST: GET ALL EMPLOYEES ----------
    @Test
    void testGetAllEmployees() {

        Employee e1 = new Employee();
        e1.setId(1L);
        e1.setName("Ravi");

        Employee e2 = new Employee();
        e2.setId(2L);
        e2.setName("Anu");

        when(employeeRepository.findAll())
                .thenReturn(Arrays.asList(e1, e2));

        List<Employee> employees = adminService.getAllEmployees();

        assertEquals(2, employees.size());
        verify(employeeRepository, times(1)).findAll();
    }

    // ---------- TEST: ADD EMPLOYEE ----------
    @Test
    void testAddEmployee() {

        Employee employee = new Employee();
        employee.setName("Siva");

        adminService.addEmployee(employee);

        verify(employeeRepository, times(1)).save(employee);
    }

    // ---------- TEST: UPDATE EMPLOYEE ----------
    @Test
    void testUpdateEmployee() {

        Employee employee = new Employee();
        employee.setId(1L);
        employee.setName("Updated Name");

        adminService.updateEmployee(employee);

        verify(employeeRepository, times(1)).update(employee);
    }

    // ---------- TEST: DELETE EMPLOYEE ----------
    @Test
    void testDeleteEmployee() {

        adminService.deleteEmployee(1L);

        verify(employeeRepository, times(1)).deleteById(1L);
    }

    // ---------- TEST: DELETE ALL EMPLOYEES ----------
    @Test
    void testDeleteAllEmployees() {

        adminService.deleteAllEmployees();

        verify(employeeRepository, times(1)).deleteAll();
    }
}
